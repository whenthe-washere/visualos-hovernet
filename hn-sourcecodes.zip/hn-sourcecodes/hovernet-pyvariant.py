import sys
import os
import shutil
from urllib.parse import quote_plus
from PyQt6.QtCore import QStringListModel, Qt, QUrl, QTimer, QSize, QPropertyAnimation, QEasingCurve, QPoint
from PyQt6.QtWidgets import (
    QApplication, QListView, QMainWindow, QTabBar, QToolButton,
    QLineEdit, QHBoxLayout, QWidget, QVBoxLayout, QMenu, QStackedWidget, QMessageBox, QFileDialog, QDialog, QLabel, QTextEdit, QPushButton,
    QTabWidget, QCheckBox, QComboBox
)
from PyQt6.QtGui import QFont, QPainter, QColor, QAction, QIcon
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEngineScript, QWebEngineProfile, QWebEngineDownloadRequest
import subprocess


class ExpandableAppTitle(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent
        
        # Title texts
        self.short_text = "HoverNet"
        self.full_text = "visualOS HoverNet - PY Variant"
        
        # Set initial state
        self.setText(self.short_text)
        self.setFixedHeight(24)
        self.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.setStyleSheet("""
            QLabel {
                background-color: transparent;
                border: none;
                font-size: 12px;
                color: #ffffff;
                padding: 0px;
                margin: 0px;
                font-weight: bold;
            }
        """)
        
        # Animation and timer setup
        self.setFixedWidth(60)  # Start with short width
        self.target_width = 60
        self.is_expanded = False
        self.hover_timer = QTimer()
        self.hover_timer.setSingleShot(True)
        self.hover_timer.timeout.connect(self.expand_title)
        
        self.leave_timer = QTimer()
        self.leave_timer.setSingleShot(True)
        self.leave_timer.timeout.connect(self.contract_title)
        
        # Animation
        self.animation = QPropertyAnimation(self, b"minimumWidth")
        self.animation.setDuration(200)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        
        # Enable mouse tracking for hover detection
        self.setMouseTracking(True)
    
    def enterEvent(self, event):
        super().enterEvent(event)
        self.hover_timer.start(500)
    
    def leaveEvent(self, event):
        super().leaveEvent(event)
        self.hover_timer.stop()
        if self.is_expanded:
            self.leave_timer.start(500)
    
    def expand_title(self):
        if not self.is_expanded:
            self.is_expanded = True
            self.setText(self.full_text)
            self.animation.setStartValue(60)
            self.animation.setEndValue(180)
            self.animation.start()
    
    def contract_title(self):
        if self.is_expanded:
            self.is_expanded = False
            self.setText(self.short_text)
            self.animation.setStartValue(180)
            self.animation.setEndValue(60)
            self.animation.start()


class CustomTabBar(QTabBar):
    def __init__(self, main_window=None):
        super().__init__(main_window)
        self.main_window = main_window
        self.setMovable(True)
        self.setTabsClosable(True)
        self.tabCloseRequested.connect(self.close_tab)

        # [+] button (square, IE11-like)
        self.plus_button = QToolButton(self)
        self.plus_button.setText("+")
        self.plus_button.setFixedSize(24, 24)
        self.plus_button.setAutoRaise(True)
        self.plus_button.setStyleSheet("""
            QToolButton {
                border: 2px solid #333366;
                border-radius: 12px;
                padding: 0px;
                color: #333366;
            }
            QToolButton:hover { 
                border: 2px solid #4D4D99; 
                color: white;
            }
        """)
        self.plus_button.clicked.connect(self.new_tab_requested)

        # Keep button positioned next to rightmost tab when tabs change / resize
        self.tabMoved.connect(lambda *_: self.update_plus_position())
        self.tabCloseRequested.connect(lambda *_: self.update_plus_position())

        # initial placement
        self.update_plus_position()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.update_plus_position()

    # override tabInserted/tabRemoved to update plus-button position (these are methods, not signals)
    def tabInserted(self, index):
        try:
            super().tabInserted(index)
        except Exception:
            pass
        self.update_plus_position()

    def tabRemoved(self, index):
        try:
            super().tabRemoved(index)
        except Exception:
            pass
        self.update_plus_position()

    def update_plus_position(self):
        w = self.plus_button.width()
        h = self.plus_button.height()
        count = self.count()
        if count > 0:
            try:
                last_rect = self.tabRect(count - 1)
                x = last_rect.right() + 6
                y = (self.height() - h) // 2
                # ensure it doesn't go past widget bounds
                if x + w > self.width() - 4:
                    x = self.width() - w - 4
            except Exception:
                x = self.width() - w - 4
                y = (self.height() - h) // 2
        else:
            x = 4
            y = (self.height() - h) // 2
        self.plus_button.move(int(x), int(y))

    def _load_icon(self, name, theme="dark"):
        """Load themed icons with alt fallback.
        name = base name (e.g. 'close', 'maximize', 'minimize')
        theme = 'dark' or 'light'
        """
        if not self._assets_root:
            return None
        root = os.path.join(self._assets_root, "icons")

        candidates = [
            f"{name}-{theme}.png",
            f"{name}-alt-{theme}.png",
            f"{name}-{('light' if theme=='dark' else 'dark')}.png",
            f"{name}-alt-{('light' if theme=='dark' else 'dark')}.png",
        ]
        for fn in candidates:
            path = os.path.join(root, fn)
            if os.path.exists(path):
                return QIcon(path)
        return None

    def new_tab_requested(self):
        if self.main_window:
            self.main_window.add_tab()
        # reposition after a new tab is created
        self.update_plus_position()

    def close_tab(self, index):
        if self.main_window:
            self.main_window.close_tab(index)
        # reposition after a tab is closed
        self.update_plus_position()


class LoadingOverlay(QWidget):
    def __init__(self, parent=None, text="Loading website, please wait..."):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        # block events while visible
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, False)
        self._text = text
        self._progress = -1  # -1 = hidden, 0-100 otherwise
        self._timer = QTimer(self)
        self._timer.start(100)
        self.hide()

    def set_progress(self, percent):
        self._progress = int(percent) if percent is not None and percent >= 0 else -1
        if self._progress >= 0:
            self._text = f"Loading... {self._progress}%"
            self.show()
            self.raise_()
        else:
            self._text = "Loading website, please wait..."
            self.hide()
        self.update()

    def paintEvent(self, ev):
        # simplified overlay: faint backdrop and centered text (no spinner)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QColor(255, 255, 255))
        painter.setPen(QColor(30, 30, 30))
        font = painter.font()
        font.setPointSize(10)
        painter.setFont(font)
        painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self._text)


class BrowserView(QWebEngineView):
    """QWebEngineView subclass that owns a LoadingOverlay and keeps it sized."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._overlay = LoadingOverlay(self)
        self._overlay.hide()
        # store current load progress for the URL-bar background when switching tabs
        self._load_progress = -1
        # Inject lightweight polyfills (structuredClone + String.replaceAll) at document creation.
        # These are fallbacks for older Chromium builds used by PyQt5; they are limited
        # (structuredClone fallback uses JSON round-trip and won't support functions/circular refs).
        try:
            profile = self.page().profile()
            poly_js = r"""
                (function(){
                if(!window.structuredClone){
                    window.structuredClone = function(obj){
                    try{ return JSON.parse(JSON.stringify(obj)); }catch(e){ return null; }
                    };
                }
                if(!String.prototype.replaceAll){
                    String.prototype.replaceAll = function(search, replace){
                    if(search instanceof RegExp) return this.replace(search, replace);
                    return this.split(String(search)).join(replace);
                    };
                }
                })();
                """
            script = QWebEngineScript()
            script.setName("ie12_polyfills")
            script.setSourceCode(poly_js)
            script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
            script.setRunsOnSubFrames(True)
            # MainWorld makes the polyfills available to page scripts
            script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
            profile.scripts().insert(script)
        except Exception:
            # fail silently if the platform/version doesn't support script injection APIs
            pass

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        # ensure overlay covers the whole view
        self._overlay.setGeometry(0, 0, self.width(), self.height())

    def overlay(self):
        return self._overlay


class HoverNetPY(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("visualOS HoverNet - PY Variant")
        self.resize(1200, 800)
        
        self.use_custom_title_bar = False
        app_font = QFont("Segoe UI", 10)
        self.setFont(app_font)

        # Security / persistence tweaks to reduce fingerprinting and keep cookies/cache
        # (best-effort: sets a modern user-agent, enables disk cache & persistent cookies,
        #  and stores profile data under %APPDATA%/IE12Profile so cookies, localStorage and cache
        #  survive across runs which helps avoid repeated bot/challenge checks)
        try:
            prof = QWebEngineProfile.defaultProfile()
            # Use a generic modern UA string (keeps "QtWebEngine" out of the UA)
            prof.setHttpUserAgent(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/140.0.0.0 Safari/537.36"
            )
            # Persist cookies and storage to disk
            prof.setPersistentCookiesPolicy(QWebEngineProfile.ForcePersistentCookies)
            base_path = os.path.join(os.getenv("APPDATA") or os.path.expanduser("~"), "IE12Profile")
            os.makedirs(base_path, exist_ok=True)
            try:
                prof.setPersistentStoragePath(base_path)
            except Exception:
                pass
            try:
                prof.setCachePath(os.path.join(base_path, "Cache"))
                prof.setHttpCacheType(QWebEngineProfile.DiskHttpCache)
            except Exception:
                pass
        except Exception:
            # non-fatal; continue without profile tweaks
            pass

        # --- Main layout ---
        central = QWidget()
        self.main_layout = QVBoxLayout(central)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)
        self.setCentralWidget(central)

        # --- Top bar (includes title bar elements) ---
        top_bar = QWidget()
        top_bar.setStyleSheet("""
            QWidget {
                background-color: #1E1E3C;
            }
        """)
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(8, 4, 8, 4)
        top_layout.setSpacing(8)
        self.top_bar = top_bar
        
        # App title (left side) - expandable on hover
        self.app_title_text = ExpandableAppTitle(self)
        
        # Window buttons (right side)
        self.minimize_btn = QPushButton("–")
        self.minimize_btn.setFixedSize(36, 26)
        self.minimize_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                font-size: 24px;
            }
            QPushButton:hover {
                color: #00CC52;
                border-radius: 3px;
            }
            QPushButton:pressed {
                color: #00993D;
                font-weight: bold;
            }
        """)
        self.minimize_btn.clicked.connect(self.minimize_window)
        
        self.maximize_btn = QPushButton("<>")
        self.maximize_btn.setFixedSize(36, 26)
        self.maximize_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                font-size: 16px;
            }
            QPushButton:hover {
                color: #3374FF;
                border-radius: 3px;
            }
            QPushButton:pressed {
                color: #6696FF;
                font-weight: bold;
            }
        """)
        self.maximize_btn.clicked.connect(self.maximize_window)
        
        self.close_btn = QPushButton("X")
        self.close_btn.setFixedSize(36, 26)
        self.close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                font-size: 16px;
            }
            QPushButton:hover {
                color: #FF3333;
                border-radius: 3px;
            }
            QPushButton:pressed {
                color: #FF6666;
                font-weight: bold;
            }
        """)
        self.close_btn.clicked.connect(self.close_window)

        # Tabs (QTabBar only, no QTabWidget)
        self.tab_bar = CustomTabBar(self)
        self.tab_bar.setFont(app_font)
        self.tab_bar.currentChanged.connect(self.switch_tab)
        self.tab_bar.tabMoved.connect(self.on_tab_moved)
        # Keep tabs at a fixed size and enable scroll buttons when overflowed
        self.tab_bar.setExpanding(False)
        self.tab_bar.setUsesScrollButtons(False)
        self.tab_bar.setElideMode(Qt.TextElideMode.ElideRight)
        # Fixed visual width for each tab so new tabs don't shrink others
        self.tab_bar.setStyleSheet("QTabBar::tab { min-width: 140px; max-width: 140px; min-height: 28px;}")

        # URL/Search bar
        self.url_bar = QLineEdit()
        self.url_bar.setPlaceholderText("Search or enter web address")
        self.url_bar.returnPressed.connect(self.load_url)
        self.url_bar.setFont(app_font)

        # Navigation buttons: Back (larger) and Forward (smaller)
        self.back_btn = QToolButton()
        self.back_btn.setText("↩")
        self.back_btn.setAutoRaise(True)
        self.back_btn.setEnabled(False)
        # larger circular style for Back
        self.back_btn.setFixedSize(QSize(30, 30))
        self.back_btn.setStyleSheet("""
            QToolButton {
            border: 2px solid #0050FF;
            border-radius: 15px;
            font-size: 20px;
            font-weight: bold;
            color: #0050FF;
            }
            QToolButton:pressed {
            color: #ffffff; 
            border: 2px solid #ffffff; 
            }
            QToolButton:disabled {
            color: #777777;
            border: 1.5px solid #444444
            }
        """)
        self.back_btn.clicked.connect(self.go_back)

        self.forward_btn = QToolButton()
        self.forward_btn.setText("↪")
        self.forward_btn.setAutoRaise(True)
        self.forward_btn.setEnabled(False)
        # smaller circular style for Forward
        self.forward_btn.setFixedSize(QSize(24, 24))
        self.forward_btn.setStyleSheet("""
            QToolButton {
            border: 2px solid #0050FF;
            border-radius: 12px;
            font-size: 17px;
            font-weight: bold;
            color: #0050FF;
            }
            QToolButton:pressed { 
            color: #ffffff; 
            border: 2px solid #ffffff; 
            }
            QToolButton:disabled {
            color: #777777;
            border: 1.5px solid #444444
            }
        """)
        self.forward_btn.clicked.connect(self.go_forward)

        # Site info button (Certificate status + Cookies)
        self.site_info_btn = QToolButton()
        self.site_info_btn.setText("⇋")
        self.site_info_btn.setAutoRaise(True)
        self.site_info_btn.setFixedSize(QSize(24, 24))
        self.site_info_btn.setStyleSheet("""
            QToolButton {
                border: 2px solid #9a9a9a;
                border-radius: 12px;
            }
            QToolButton:pressed { background: rgba(190,215,255,255); }
        """)
        if self._show_site_info:
            self.site_info_btn.setText("⇌")
            self.site_info_btn.setStyleSheet("""
                QToolButton {
                    border: 2px solid #3C993C;
                    border-radius: 12px;
                    color: #3C993C;
                }
                QToolButton:pressed { border: 2px solid #ffffff; color: white; }
            """)
        if self._show_site_info is None:
            self.site_info_btn.setText("✕")
            self.site_info_btn.setStyleSheet("""
                QToolButton {
                    border: 2px solid #9a9a9a;
                    border-radius: 12px;
                    background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 rgba(235,245,255,255), stop:1 rgba(255,128,128,255));
                }
                QToolButton:pressed { background: rgba(204,102,104,255); }
            """)
        self.site_info_btn.clicked.connect(self._show_site_info)

        # Refresh button (placed in the URL/nav container)
        self.refresh_btn = QToolButton()
        self.refresh_btn.setText("⟳")
        self.refresh_btn.setAutoRaise(True)
        self.refresh_btn.setFixedSize(QSize(26, 26))
        self.refresh_btn.setStyleSheet("""
            QToolButton { 
            color: #0050FF; 
            border: 2px solid #0050FF; 
            border-radius: 13px;
            }
            QToolButton:pressed { 
            color: #FFFFFF; 
            border: 2px solid #FFFFFF; 
            }
        """)
        self.refresh_btn.clicked.connect(self.go_refresh)

        # Put nav buttons next to the URL bar so they feel integrated
        # Create a small container for url + nav so layout spacing stays correct
        nav_container = QWidget()
        nav_layout = QHBoxLayout(nav_container)
        nav_layout.setContentsMargins(0, 0, 0, 0)
        nav_layout.setSpacing(6)
        nav_layout.addWidget(self.back_btn)
        nav_layout.addWidget(self.forward_btn)
        nav_layout.addWidget(self.url_bar)
        nav_layout.addWidget(self.site_info_btn)
        nav_layout.addWidget(self.refresh_btn)
        self.nav_container = nav_container

        # Right-side buttons
        self.home_btn = QToolButton()
        self.home_btn.setText("Home")
        self.home_btn.clicked.connect(self.go_home)
        self.home_btn.setStyleSheet("""
            QToolButton { background: transparent; border: none; }
            QToolButton:hover { color: #e53935; font-weight: bold; }
        """)

        self.ws_btn = QToolButton()
        self.ws_btn.setText("WS")
        self.ws_btn.clicked.connect(self.whenthes_space)
        self.ws_btn.setStyleSheet("""
            QToolButton { background: transparent; border: none; }
            QToolButton:hover { color: #004BFF; font-weight: bold; }
        """)

        self.tools_btn = QToolButton()
        self.tools_btn.setText("Tools    ")
        self.tools_btn.setStyleSheet("""
            QToolButton { background: transparent; border: none; }
            QToolButton:hover { color: #1976d2; font-weight: bold; }
        """)


        # Build the expanded Extras/Tools menu
        self.tools_menu = QMenu()

        # File submenu (placeholder: Open File)
        act_file = QAction("File", self)
        act_file.triggered.connect(self._act_file)
        self.tools_menu.addAction(act_file)

        # Zoom submenu
        zoom_menu = QMenu("Zoom", self)
        act_zoom_in = QAction("Zoom In", self)
        act_zoom_in.setShortcut("[Ctrl] + [+]")
        act_zoom_in.triggered.connect(lambda: self._zoom(1.1))
        zoom_menu.addAction(act_zoom_in)
        act_zoom_out = QAction("Zoom Out", self)
        act_zoom_out.setShortcut("[Ctrl] + [-]")
        act_zoom_out.triggered.connect(lambda: self._zoom(1/1.1))
        zoom_menu.addAction(act_zoom_out)
        act_zoom_reset = QAction("Reset Zoom", self)
        act_zoom_reset.setShortcut("[Ctrl] + [0]")
        act_zoom_reset.triggered.connect(lambda: self._zoom_reset())
        zoom_menu.addAction(act_zoom_reset)
        self.tools_menu.addMenu(zoom_menu)

        # Safety submenu (placeholder actions)
        safety_menu = QMenu("Safety", self)
        act_delete_history = QAction("Delete browsing history", self)
        act_delete_history.triggered.connect(self._show_delete_history_dialog)
        safety_menu.addAction(act_delete_history)
        self.act_activex_filtering = QAction("ActiveX Filtering", self)
        self.act_activex_filtering.setCheckable(True)
        self.act_activex_filtering.setChecked(False)
        self.act_activex_filtering.triggered.connect(self._toggle_activex_filtering)
        safety_menu.addAction(self.act_activex_filtering)
        self.tools_menu.addMenu(safety_menu)


        act_downloads = QAction("Downloaded File History", self)
        act_downloads.triggered.connect(self._show_downloads_dialog)
        self.tools_menu.addAction(act_downloads)

        act_addons = QAction("Extensions", self)
        act_addons.setDisabled(True)
        act_addons.triggered.connect(lambda: QMessageBox.information(self, "Manage add-ons", "This feature is not implemented yet."))
        self.tools_menu.addAction(act_addons)

        # Developer Tools (open DevTools window)
        act_devtools = QAction("Developer Tools", self)
        act_devtools.setShortcut("F12")
        act_devtools.triggered.connect(self._open_devtools_for_current)
        self.tools_menu.addAction(act_devtools)

        # Separator before settings-ish items
        self.tools_menu.addSeparator()

        # Internet Options / Settings (already present previously) — keep as final entries
        act_hovernet_settings = QAction("HoverNet Settings", self)
        act_hovernet_settings.triggered.connect(self._show_hovernet_settings)
        self.tools_menu.addAction(act_hovernet_settings)

        act_about = QAction("About HoverNet", self)
        act_about.triggered.connect(lambda: QMessageBox.information(
            self,
            "visualOS HoverNet",
            '<span style="font-size:16px; color:#0078d7;">visualOS HoverNet(wb redesign/PY)</span>'
            '<br><span style="font-size:12px;">whenthe\'s browser, recreated.</span>'
            '<br><span style="font-size:12px;">Version: 2(PY: Python Variant)</span>'
            '<br><span style="font-size:12px;">Python Version: 3.12.9</span>'
            '<br><span style="font-size:12px;">Browser made with PyQt6(This upgrade will not come to the IE variant)</span>'
            '<br><span style="font-size:12px;">Release Notes are located in "HoverNet Settings/HoverNet/Release Notes". </span>'
        ))
        self.tools_menu.addAction(act_about)

        self.tools_btn.setMenu(self.tools_menu)
        self.tools_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)

        # Assemble top bar: app title, nav + address bar, tabs, and window buttons
        top_layout.addWidget(self.app_title_text)
        top_layout.addWidget(nav_container, stretch=2)
        top_layout.addWidget(self.tab_bar, stretch=3)
        top_layout.addWidget(self.home_btn)
        top_layout.addWidget(self.ws_btn)
        top_layout.addWidget(self.tools_btn)
        top_layout.addWidget(self.minimize_btn)
        top_layout.addWidget(self.maximize_btn)
        top_layout.addWidget(self.close_btn)

        self.main_layout.addWidget(top_bar)

        # --- Browser content area ---
        self.browser_area = QStackedWidget()
        self.main_layout.addWidget(self.browser_area)

        # Start with one tab
        self.add_tab("https://www.google.com")

        # --- Download tracking ---
        self._downloads = []  # List of (filename, status, path)
        QWebEngineProfile.defaultProfile().downloadRequested.connect(self._on_download_requested)
        self._download_path = os.path.expanduser('~')
        
        # Apply custom title bar setting
        self.apply_custom_title_bar_setting()

        # Ensure external assets (icons/images) are installed when running as frozen EXE
        try:
            self._assets_root = self._ensure_installed_assets()
        except Exception:
            self._assets_root = None

        # Drag state for custom title bar
        self._drag_active = False
        self._drag_pending = False
        self._drag_start_pos = QPoint(0, 0)
        self._drag_maximized = False
        self._drag_ratio_x = 0.5
        self._drag_window_offset = QPoint(0, 0)
        self._press_pos_in_topbar = QPoint(0, 0)
        self._press_window_offset = QPoint(0, 0)
        # Install event filters on the top bar and all of its children to enable dragging everywhere
        self._install_topbar_drag_filters()

    # --- Custom title bar drag handling ---
    def _is_frozen(self):
        try:
            return getattr(sys, 'frozen', False) is True
        except Exception:
            return False

    def _ensure_installed_assets(self):
        if self._is_frozen():
            base_dir = os.path.dirname(sys.executable)
        else:
            base_dir = os.path.dirname(os.path.abspath(__file__))

        internal_root = os.path.join(base_dir, "_internal")
        source_dir = os.path.join(internal_root, "HoverNet")

        program_files = os.environ.get("ProgramFiles") or os.path.join(os.path.expanduser("~"), "AppData", "Local", "Programs")
        dest_dir = os.path.join(program_files, "HoverNet")

        def _sync_dir(src, dst):
            os.makedirs(dst, exist_ok=True)
            for root, dirs, files in os.walk(src):
                rel = os.path.relpath(root, src)
                target_root = os.path.join(dst, rel) if rel != "." else dst
                os.makedirs(target_root, exist_ok=True)
                for f in files:
                    src_f = os.path.join(root, f)
                    dst_f = os.path.join(target_root, f)
                    try:
                        # Copy if new, missing, or modified
                        if not os.path.exists(dst_f) or os.path.getmtime(src_f) > os.path.getmtime(dst_f):
                            shutil.copy2(src_f, dst_f)
                    except Exception:
                        continue

        if os.path.isdir(dest_dir):
            if os.path.isdir(source_dir):
                _sync_dir(source_dir, dest_dir)  # update missing/outdated files
            return dest_dir

        if os.path.isdir(source_dir):
            try:
                _sync_dir(source_dir, dest_dir)
                return dest_dir
            except PermissionError:
                appdata = os.getenv("APPDATA") or os.path.expanduser("~")
                dest_dir2 = os.path.join(appdata, "HoverNet")
                _sync_dir(source_dir, dest_dir2)
                return dest_dir2

        return None

        #This is currently disabled, but it will be enabled later when I fix it
        def _sync_dir(src, dst):
            os.makedirs(dst, exist_ok=True)
            for root, dirs, files in os.walk(src):
                rel = os.path.relpath(root, src)
                target_root = os.path.join(dst, rel) if rel != "." else dst
                os.makedirs(target_root, exist_ok=True)
                for d in dirs:
                    os.makedirs(os.path.join(target_root, d), exist_ok=True)
                for f in files:
                    src_f = os.path.join(root, f)
                    dst_f = os.path.join(target_root, f)
                    try:
                        # Copy if new or modified
                        if not os.path.exists(dst_f) or os.path.getmtime(src_f) > os.path.getmtime(dst_f):
                            shutil.copy2(src_f, dst_f)
                    except Exception:
                        continue

        # 1) If Program Files\HoverNet already exists and has files, prefer it
        if _dir_has_files(dest_dir):
            return dest_dir

        # 2) Otherwise, if _internal/HoverNet exists, copy it to Program Files or APPDATA
        if os.path.isdir(source_dir):
            try:
                _sync_dir(source_dir, dest_dir)
                return dest_dir
            except PermissionError:
                # Fallback to %APPDATA%/HoverNet if Program Files is not writable
                appdata = os.getenv("APPDATA") or os.path.expanduser("~")
                dest_dir2 = os.path.join(appdata, "HoverNet")
                try:
                    _sync_dir(source_dir, dest_dir2)
                    return dest_dir2
                except Exception:
                    return None
            except Exception:
                return None

        # 3) Nothing available
        return None
    def _install_topbar_drag_filters(self):
        try:
            from PyQt6.QtWidgets import QWidget as _QWidget
        except Exception:
            _QWidget = None
        try:
            if getattr(self, 'top_bar', None) is None:
                return
            # Watch the window as well to keep receiving events while grabbing
            self.installEventFilter(self)
            self.top_bar.installEventFilter(self)
            if _QWidget is not None:
                for w in self.top_bar.findChildren(_QWidget):
                    try:
                        w.installEventFilter(self)
                    except Exception:
                        continue
        except Exception:
            pass

    def _is_topbar_object(self, obj):
        tb = getattr(self, 'top_bar', None)
        if tb is None or obj is None:
            return False
        if obj is tb:
            return True
        try:
            p = getattr(obj, 'parentWidget', lambda: None)()
            while p is not None:
                if p is tb:
                    return True
                p = p.parentWidget()
        except Exception:
            return False
        return False

    def _is_in_drag_region(self, pos_in_top_bar):
        """Return True if mouse is in the custom title bar region suitable for dragging.
        We allow the entire top bar to initiate drag to increase usable area."""
        if not self.use_custom_title_bar:
            return False
        if not hasattr(self, 'top_bar'):
            return False
        # Allow anywhere on the top bar. Clicks will still work because we only
        # activate dragging once the mouse has moved beyond a threshold.
        return True

    def eventFilter(self, obj, event):
        try:
            from PyQt6.QtCore import QEvent
        except Exception:
            QEvent = None

        if QEvent is not None and (self._is_topbar_object(obj) or obj is self):
            et = event.type()
            # Mouse press: initiate potential drag
            if et == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
                # Always compute position relative to the top bar using global coordinates
                pos_in_top_bar = self.top_bar.mapFromGlobal(event.globalPosition().toPoint())
                if self._is_in_drag_region(pos_in_top_bar):
                    self._drag_pending = True
                    self._press_pos_in_topbar = QPoint(pos_in_top_bar.x(), pos_in_top_bar.y())
                    self._drag_start_pos = event.globalPosition().toPoint()
                    self._drag_maximized = self.isMaximized()
                    # Capture the press offset in window coordinates to preserve exact anchor on restore
                    self._press_window_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                    # Ratio of cursor across the window width, used when restoring from maximized
                    w = max(1, self.width())
                    self._drag_ratio_x = max(0.0, min(1.0, pos_in_top_bar.x() / float(w)))
                    # Offset used for normal-size dragging (will be refined when drag activates)
                    self._drag_window_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                    return False
            # Mouse move: perform drag
            if et == QEvent.Type.MouseMove and self._drag_active:
                global_pos = event.globalPosition().toPoint()
                if self._drag_maximized:
                    # Restore to normal size and position window such that:
                    # - the middle of the top bar is directly under the cursor
                    self.showNormal()
                    new_width = max(1, self.width())
                    # Compute vertical center of the top bar relative to the window
                    topbar_center_y = int(getattr(self, 'top_bar').y() + getattr(self, 'top_bar').height() / 2)
                    # Offset from window top-left to the top bar center point horizontally/vertically
                    anchor_offset = QPoint(int(new_width / 2), topbar_center_y)
                    # Place window so that anchor_offset maps to the cursor position
                    target_middle = global_pos - anchor_offset
                    self.move(target_middle)
                    # Maintain this anchor during continued dragging
                    self._drag_window_offset = QPoint(anchor_offset.x(), anchor_offset.y())
                    self._drag_maximized = False
                else:
                    # Normal drag: move window keeping the press offset
                    top_left = global_pos - self._drag_window_offset
                    self.move(top_left)
                return True
            if et == QEvent.Type.MouseMove and self._drag_pending and not self._drag_active:
                # Activate drag only after exceeding threshold so clicks still work
                from PyQt6.QtWidgets import QApplication as _QtApp
                global_pos = event.globalPosition().toPoint()
                threshold = getattr(_QtApp.instance(), 'startDragDistance', lambda: 10)()
                dx = abs(global_pos.x() - self._drag_start_pos.x())
                dy = abs(global_pos.y() - self._drag_start_pos.y())
                if dx >= threshold or dy >= threshold:
                    self._drag_active = True
                    try:
                        self.grabMouse()
                    except Exception:
                        pass
                    # Update offset now that we are dragging
                    self._drag_window_offset = global_pos - self.frameGeometry().topLeft()
                    return True
            # Mouse release: end drag
            if et == QEvent.Type.MouseButtonRelease and event.button() == Qt.MouseButton.LeftButton:
                if self._drag_active:
                    try:
                        self.releaseMouse()
                    except Exception:
                        pass
                self._drag_active = False
                self._drag_pending = False
                self._drag_maximized = False
                return False
        return super().eventFilter(obj, event)
    
    def apply_custom_title_bar_setting(self):
        """Apply the custom title bar setting"""
        if self.use_custom_title_bar:
            # Hide the default window title bar and show custom elements
            self.setWindowFlags(self.windowFlags() | Qt.WindowType.FramelessWindowHint)
            self.app_title_text.show()
            self.minimize_btn.show()
            self.maximize_btn.show()
            self.close_btn.show()
        else:
            # Show the default window title bar and hide custom elements
            self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.FramelessWindowHint)
            self.app_title_text.hide()
            self.minimize_btn.hide()
            self.maximize_btn.hide()
            self.close_btn.hide()
        self.show()  # Refresh the window to apply changes
    
    def set_custom_title_bar_enabled(self, enabled):
        """Enable or disable custom title bar"""
        self.use_custom_title_bar = enabled
        self.apply_custom_title_bar_setting()

    
    def minimize_window(self):
        self.showMinimized()
    
    def maximize_window(self):
        if self.isMaximized():
            self.showNormal()
            self.maximize_btn.setText("<>")
        else:
            self.showMaximized()
            self.maximize_btn.setText("><")
    
    def close_window(self):
        self.close()

    def normalize_input(self, text):
        text = (text or "").strip()
        if not text:
            return "https://www.google.com"
        # If contains spaces -> treat as search
        if " " in text:
            return "https://www.google.com/search?q=" + quote_plus(text)
        # If looks like a bare domain or starts with www.
        if text.startswith("www.") or ("." in text and " " not in text):
            if not text.startswith(("http://", "https://")):
                return "http://" + text
            return text
        # Otherwise treat as search
        return "https://www.google.com/search?q=" + quote_plus(text)

    def add_tab(self, url="https://www.google.com"):
        url = self.normalize_input(url)
        browser = BrowserView()
        browser.setUrl(QUrl(url))
        stack_index = self.browser_area.addWidget(browser)
        self.browser_area.setCurrentIndex(stack_index)

        tab_index = self.tab_bar.addTab("New Tab")
        self.tab_bar.setCurrentIndex(tab_index)

        browser.urlChanged.connect(lambda qurl, browser=browser: self.update_url(qurl, browser))
        # loading signals -> update overlay and tab text
        browser.loadStarted.connect(lambda b=browser: self.on_load_started(b))
        browser.loadProgress.connect(lambda p, b=browser: self.on_load_progress(b, p))
        browser.loadFinished.connect(lambda ok, b=browser: self.on_load_finished(b, ok))
        # Keep navigation buttons in sync with this view's history
        try:
            browser.history().canGoBackChanged.connect(lambda enabled, b=browser: self._update_nav_buttons_for(b))
            browser.history().canGoForwardChanged.connect(lambda enabled, b=browser: self._update_nav_buttons_for(b))
        except Exception:
            # older PyQt versions may not expose these signals; fall back to updating on load events
            browser.urlChanged.connect(lambda *_: self._update_nav_buttons_for(browser))
            browser.loadFinished.connect(lambda *_: self._update_nav_buttons_for(browser))

        # If this is the active tab, update the URL bar immediately
        if browser == self.browser_area.currentWidget():
            self.url_bar.setText(browser.url().toString())


    # Loading helpers ----------------------------------------------------
    def on_load_started(self, browser):
        ov = getattr(browser, "overlay", lambda: None)()
        if ov:
            ov.set_progress(0)
            ov.show()
        browser._load_progress = 0
        self.set_urlbar_progress(0)
        idx = self.browser_area.indexOf(browser)
        if idx != -1:
            self.tab_bar.setTabText(idx, "Loading... 0%")

    def on_load_progress(self, browser, percent):
        ov = getattr(browser, "overlay", lambda: None)()
        if ov:
            ov.set_progress(percent)
        browser._load_progress = percent
        # update the URL bar background only if this tab is current
        if browser == self.browser_area.currentWidget():
            self.set_urlbar_progress(percent)
        idx = self.browser_area.indexOf(browser)
        if idx != -1:
            self.tab_bar.setTabText(idx, f"Loading... {percent}%")

    def on_load_finished(self, browser, ok):
        ov = getattr(browser, "overlay", lambda: None)()
        if ov:
            ov.set_progress(-1)
            ov.hide()
        browser._load_progress = -1
        # clear URL bar background if this is the current tab
        if browser == self.browser_area.currentWidget():
            self.set_urlbar_progress(-1)
        idx = self.browser_area.indexOf(browser)
        if idx != -1:
            title = browser.title() or "New Tab"
            self.tab_bar.setTabText(idx, title)

    def set_urlbar_progress(self, percent):
        if percent is None or percent < 0:
            self.url_bar.setStyleSheet("")
            return
        frac = max(0.0, min(1.0, percent / 100.0))
        stop = f"{frac:.3f}"
        self.url_bar.setStyleSheet(f"""
        QLineEdit {{
        padding: 3px;
        border: 1px solid #9a9a9a;
        background: qlineargradient(x0:0, y2:0, x2:1, y2:0,
            stop:0 rgba(0,128,0,255),
            stop:{stop} rgba(0,128,0,255),
            stop:{stop} rgba(0,0,0,0),
            stop:1 rgba(0,0,0,0));
        }}
        """)

    def load_url(self):
        raw = self.url_bar.text()
        url = self.normalize_input(raw)
        cur = self.browser_area.currentWidget()
        if cur:
            cur.setUrl(QUrl(url))

    def update_url(self, q, browser=None):
        if browser == self.browser_area.currentWidget():
            self.url_bar.setText(q.toString())

    def close_tab(self, index):
        if self.tab_bar.count() > 1:
            # Remove tab from tab bar
            self.tab_bar.removeTab(index)
            # Remove corresponding widget from stacked widget
            widget = self.browser_area.widget(index)
            self.browser_area.removeWidget(widget)
            widget.deleteLater()
            # Ensure the stacked widget current index follows tab bar current index
            cur = self.tab_bar.currentIndex()
            if cur >= 0:
                self.browser_area.setCurrentIndex(cur)
                self.url_bar.setText(self.browser_area.currentWidget().url().toString())

    def go_home(self):
        cur = self.browser_area.currentWidget()
        if cur:
            cur.setUrl(QUrl("https://www.google.com"))

    def whenthes_space(self):
        cur = self.browser_area.currentWidget()
        if cur:
            cur.setUrl(QUrl("https://www.sites.google.com/view/whenthesspace"))

    def switch_tab(self, index):
        if index >= 0 and index < self.browser_area.count():
            self.browser_area.setCurrentIndex(index)
            cur = self.browser_area.currentWidget()
            if cur:
                self.url_bar.setText(cur.url().toString())
                # restore URL-bar progress visual for the newly selected tab
                prog = getattr(cur, "_load_progress", -1)
                self.set_urlbar_progress(prog)

    def on_tab_moved(self, from_index, to_index):
        # Keep stacked widget in sync with tab bar order
        widget = self.browser_area.widget(from_index)
        if widget is None:
            return
        # Remove and re-insert at new position
        self.browser_area.removeWidget(widget)
        self.browser_area.insertWidget(to_index, widget)
        # Keep the same current tab selected
        cur = self.tab_bar.currentIndex()
        if cur >= 0:
            self.browser_area.setCurrentIndex(cur)

        # update nav buttons whenever the tab order or selection changes
        curw = self.browser_area.currentWidget()
        if curw:
            self._update_nav_buttons_for(curw)

    # navigation helpers ------------------------------------------------
    def _update_nav_buttons_for(self, browser):
        """Enable/disable nav buttons based on the given browser's history.
        Only updates buttons if the browser is the current view."""
        cur = self.browser_area.currentWidget()
        if browser is None or browser != cur:
            return
        try:
            hb = browser.history().canGoBack()
            hf = browser.history().canGoForward()
        except Exception:
            # fallback: assume both disabled if we can't query
            hb = False
            hf = False
        self.back_btn.setEnabled(bool(hb))
        self.forward_btn.setEnabled(bool(hf))

    def go_back(self):
        cur = self.browser_area.currentWidget()
        if cur and cur.history().canGoBack():
            cur.back()

    def go_forward(self):
        cur = self.browser_area.currentWidget()
        if cur and cur.history().canGoForward():
            cur.forward()

    def go_refresh(self):
        cur = self.browser_area.currentWidget()
        if cur:
            cur.reload()

    # helpers for the Tools/Extras menu (were referenced but missing)
    def current_view(self):
        return self.browser_area.currentWidget() if self.browser_area.count() else None

    def _act_file(self):
        QMessageBox.information(self, "File", "File menu: not implemented")

    def _zoom(self, factor):
        cur = self.current_view()
        if cur:
            cur.setZoomFactor(cur.zoomFactor() * factor)

    def _zoom_reset(self):
        cur = self.current_view()
        if cur:
            cur.setZoomFactor(1.0)

    def _open_devtools_for_current(self):
        cur = self.current_view()
        if not cur:
            QMessageBox.information(self, "Developer Tools", "No active page")
            return
        dev = QWebEngineView()
        dev.setWindowTitle("Developer Tools")
        dev.resize(900, 600)
        try:
            cur.page().setDevToolsPage(dev.page())
            dev.show()
        except Exception:
            QMessageBox.information(self, "Developer Tools", "Unable to open DevTools on this platform/version")
        if not hasattr(self, "_devtools_windows"):
            self._devtools_windows = []
        self._devtools_windows.append(dev)
        dev.destroyed.connect(lambda: self._devtools_windows.remove(dev) if dev in getattr(self, "_devtools_windows", []) else None)

    def _show_site_info(self):
        cur = self.current_view()
        if not cur:
            QMessageBox.information(self, "Site info", "No active page")
            return

        url = cur.url()
        host = url.host() or url.toString()
        scheme = url.scheme().lower()
        secure = (scheme == "https")

        dlg = QDialog(self)
        dlg.setWindowTitle(f"Site information — {host}")
        layout = QVBoxLayout(dlg)

        lbl = QLabel(f"URL: {url.toString()}<br>Connection: {'Secure (HTTPS)' if secure else 'Not secure'}")
        lbl.setTextFormat(Qt.TextFormat.RichText)
        layout.addWidget(lbl)

        cert_lbl = QLabel("Certificate: " + ("Present (details not available in this build)" if secure else "None"))
        layout.addWidget(cert_lbl)

        layout.addWidget(QLabel("Cookies:"))
        cookies_view = QTextEdit()
        cookies_view.setReadOnly(True)
        cookies_view.setPlainText("Loading...")
        layout.addWidget(cookies_view)

        btn_close = QPushButton("Close")
        btn_close.clicked.connect(dlg.accept)
        layout.addWidget(btn_close)

        # Try to read cookies via document.cookie (works for same-origin pages)
        try:
            cur.page().runJavaScript("document.cookie", lambda result: _fill_cookies(result, cookies_view))
        except Exception:
            cookies_view.setPlainText("(Unable to retrieve cookies)")

        def _fill_cookies(result, widget):
            if result is None:
                widget.setPlainText("(no cookies or access denied)")
                return
            if isinstance(result, str):
                if not result.strip():
                    widget.setPlainText("(no cookies)")
                    return
                lines = [c.strip() for c in result.split(";") if c.strip()]
                widget.setPlainText("\n".join(lines))
                return
            widget.setPlainText(str(result))

        dlg.setModal(True)
        dlg.resize(420, 300)
        dlg.exec()

    def _show_hovernet_settings(self):
        dlg = HoverNetSettingsDialog(self)
        dlg.exec()

    def _show_delete_history_dialog(self):
        dlg = DeleteHistoryDialog(self)
        dlg.exec()

    def _toggle_activex_filtering(self):
        enabled = self.act_activex_filtering.isChecked()
        msg = "ActiveX Filtering is now {}.".format("enabled" if enabled else "disabled")
        QMessageBox.information(self, "ActiveX Filtering", msg)

    def _on_download_requested(self, download: QWebEngineDownloadRequest):
        # Ask user where to save the file, default to _download_path
        suggested = download.downloadFileName() or download.url().fileName() or "downloaded_file"
        default_dir = self._download_path if hasattr(self, '_download_path') else os.path.expanduser('~')
        path, _ = QFileDialog.getSaveFileName(self, "Save File", os.path.join(default_dir, suggested))
        if not path:
            download.cancel()
            return
        folder = os.path.dirname(path)
        if not os.path.exists(folder):
            os.makedirs(folder, exist_ok=True)
        filename = os.path.basename(path)
        download.setDownloadDirectory(folder)
        download.setDownloadFileName(filename)
        download.accept()
        entry = {"filename": os.path.basename(path), "status": "Downloading", "path": path, "item": download}
        self._downloads.append(entry)
        download.finished.connect(lambda: self._on_download_finished(entry))
    def _on_download_finished(self, entry):
        entry["status"] = "Completed" if entry["item"].state() == QWebEngineDownloadRequest.DownloadState.DownloadCompleted else "Failed"

    def _show_downloads_dialog(self):
        dlg = ViewDownloadsDialog(self._downloads, self)
        dlg.exec()


class HoverNetSettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.resize(400, 250)
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget(self)
        layout.addWidget(self.tabs)
        QMessageBox.warning(self, "Warning", "Most of the settings in here currently does not function.\nTheir functions will be implemented in the future.")
        tab_themes = QWidget()
        v_themes = QVBoxLayout(tab_themes)
        lbl_warn2 = QLabel("PyQt6 has it's own themes that automatically adjust to the system theme. And since Night Mode doesn't control that yet, this setting is useless.")
        lbl_warn2.setWordWrap(True)
        v_themes.addWidget(lbl_warn2)
        self.chk_night = QCheckBox("Night Mode")
        v_themes.addWidget(self.chk_night)
        
        # Custom title bar setting
        self.chk_custom_title_bar = QCheckBox("Use HoverNet title bar(HUGE WIP)")
        self.chk_custom_title_bar.setChecked(getattr(parent, 'use_custom_title_bar', True))
        self.chk_custom_title_bar.stateChanged.connect(self.on_custom_title_bar_changed)
        v_themes.addWidget(self.chk_custom_title_bar)
        v_themes.addStretch(1)
        self.tabs.addTab(tab_themes, "Theme")

        # Account Tab
        tab_account = QWidget()
        v_account = QVBoxLayout(tab_account)
        btn_gmail = QPushButton("G-Mail")
        btn_gmail.clicked.connect(lambda: QMessageBox.information(self, "Account", "Account management is not implemented yet."))
        btn_ms = QPushButton("Microsoft Account")
        btn_ms.clicked.connect(lambda: QMessageBox.information(self, "Account", "Account management is not implemented yet."))
        v_account.addWidget(btn_gmail)
        v_account.addWidget(btn_ms)
        v_account.addStretch(1)
        self.tabs.addTab(tab_account, "Account")

        # Tabs Tab
        tab_tabs = QWidget()
        v_tabs = QVBoxLayout(tab_tabs)
        lbl_newtab = QLabel("When a new tab is opened, open")
        v_tabs.addWidget(lbl_newtab)
        self.edit_newtab_url = QLineEdit("https://www.google.com")
        v_tabs.addWidget(self.edit_newtab_url)
        lbl_startup = QLabel("On startup,")
        v_tabs.addWidget(lbl_startup)
        self.combo_startup = QComboBox()
        self.combo_startup.addItems(["Open a new tab", "Continue from last session", "Show a blank page"])  # Add more options if needed
        v_tabs.addWidget(self.combo_startup)
        btn_save = QPushButton("Save Settings(Unavaiable)")
        btn_save.setEnabled(False)
        v_tabs.addWidget(btn_save)
        v_tabs.addStretch(1)
        self.tabs.addTab(tab_tabs, "Tabs")

        tab_relnotes = QWidget()
        v_relnotes = QVBoxLayout(tab_relnotes)
        notes = QLabel("visualOS HoverNet (PY Variant)\n"
            "Changed tab bar background\n"
            "Changed tab bar font(not fully but whatever)")
        notes.setWordWrap(True)
        v_relnotes.addWidget(notes)
        self.tabs.addTab(tab_relnotes, "Release Notes")

        # Downloads Tab
        tab_downloads = QWidget()
        v_downloads = QVBoxLayout(tab_downloads)
        v_downloads.addWidget(QLabel("Default download path:"))
        self.edit_download_path = QLineEdit(getattr(parent, '_download_path', os.path.expanduser('~')))
        btn_browse = QPushButton("Browse...")
        v_downloads.addWidget(self.edit_download_path)
        v_downloads.addWidget(btn_browse)
        v_downloads.addStretch(1)
        self.tabs.addTab(tab_downloads, "Downloads")
        def browse_path():
            path = QFileDialog.getExistingDirectory(self, "Select Download Folder", self.edit_download_path.text())
            if path:
                self.edit_download_path.setText(path)
        btn_browse.clicked.connect(browse_path)
        # Save path on close
        def save_path():
            path = self.edit_download_path.text()
            if path and not os.path.exists(path):
                os.makedirs(path, exist_ok=True)
            if parent is not None:
                parent._download_path = path
        self.accepted.connect(save_path)
    
    def on_custom_title_bar_changed(self, state):
        enabled = state == Qt.CheckState.Checked.value
        if self.parent() and hasattr(self.parent(), 'set_custom_title_bar_enabled'):
            self.parent().set_custom_title_bar_enabled(enabled)

class DeleteHistoryDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Delete Browsing History")
        self.resize(400, 300)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Select the items you want to delete:", self))
        self.chk_history = QCheckBox("History")
        self.chk_cookies = QCheckBox("Cookies and website data")
        self.chk_cache = QCheckBox("Cached images and files")
        self.chk_passwords = QCheckBox("Saved passwords")
        self.chk_form = QCheckBox("Form data")
        self.chk_downloads = QCheckBox("Download history")
        for chk in [self.chk_history, self.chk_cookies, self.chk_cache, self.chk_passwords, self.chk_form, self.chk_downloads]:
            layout.addWidget(chk)
        layout.addStretch(1)
        btns = QHBoxLayout()
        btn_delete = QPushButton("Delete")
        btn_cancel = QPushButton("Cancel")
        btn_delete.clicked.connect(self.do_delete)
        btn_cancel.clicked.connect(self.reject)
        btns.addWidget(btn_delete)
        btns.addWidget(btn_cancel)
        layout.addLayout(btns)
    def do_delete(self):
        # Placeholder: just show a confirmation
        QMessageBox.information(self, "Delete Browsing History", "Selected items deleted (placeholder)")
        self.accept()


class ViewDownloadsDialog(QDialog):
    def __init__(self, downloads, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Downloads")
        self.resize(600, 350)
        self.downloads = downloads
        layout = QVBoxLayout(self)
        self.list = QListView(self)
        self.model = QStringListModel()
        self.update_list()
        self.list.setModel(self.model)
        layout.addWidget(self.list)
        btns = QHBoxLayout()
        self.btn_open = QPushButton("Open File")
        self.btn_folder = QPushButton("Open Folder")
        self.btn_clear = QPushButton("Clear List")
        btns.addWidget(self.btn_open)
        btns.addWidget(self.btn_folder)
        btns.addWidget(self.btn_clear)
        layout.addLayout(btns)
        self.btn_open.clicked.connect(self.open_file)
        self.btn_folder.clicked.connect(self.open_folder)
        self.btn_clear.clicked.connect(self.clear_list)
    def update_list(self):
        items = [f"{d['filename']} - {d['status']}" for d in self.downloads]
        self.model.setStringList(items)
    def open_file(self):
        idx = self.list.currentIndex().row()
        if 0 <= idx < len(self.downloads):
            path = self.downloads[idx]['path']
            if os.path.exists(path):
                os.startfile(path)
            else:
                QMessageBox.warning(self, "Open File", "File does not exist.")
    def open_folder(self):
        idx = self.list.currentIndex().row()
        if 0 <= idx < len(self.downloads):
            path = self.downloads[idx]['path']
            folder = os.path.dirname(path)
            if os.path.exists(folder):
                subprocess.Popen(f'explorer "{folder}"')
            else:
                QMessageBox.warning(self, "Open Folder", "Folder does not exist.")
    def clear_list(self):
        self.downloads.clear()
        self.update_list()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = HoverNetPY()
    window.show()
    sys.exit(app.exec())